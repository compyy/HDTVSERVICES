# -*- coding: utf-8 -*-

import xbmc

url = 'http://ip.sltv.be:8000/get.php?username=Rvkqp89xnf&password=fU0Dq2LoAx&type=m3u&output=ts'
xbmc.Player().play(url)